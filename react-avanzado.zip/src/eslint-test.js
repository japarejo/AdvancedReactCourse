const ejemplo = 123;
